package es.cdm.jaxb;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;

import javax.xml.XMLConstants;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class RepositorioXml {
    private final JAXBContext contexto;
    private final Schema esquema;

    public RepositorioXml(Path rutaXsd) throws JAXBException, SAXException {
        contexto = JAXBContext.newInstance(Libreria.class);
        SchemaFactory fabrica = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        fabrica.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        fabrica.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        esquema = fabrica.newSchema(rutaXsd.toFile());
    }

    public Libreria cargar(Path rutaXml) throws JAXBException {
        Unmarshaller lector = contexto.createUnmarshaller();
        lector.setSchema(esquema);
        lector.setEventHandler(evento -> false);
        return (Libreria) lector.unmarshal(rutaXml.toFile());
    }

    public void guardar(Libreria libreria, Path destino) throws JAXBException, IOException {
        Marshaller escritor = contexto.createMarshaller();
        escritor.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        escritor.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        escritor.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, "libreria.xsd");
        escritor.setSchema(esquema);
        escritor.setEventHandler(evento -> false);

        // Validar durante el marshalling antes de escribir o sustituir el archivo.
        ByteArrayOutputStream xml = new ByteArrayOutputStream();
        escritor.marshal(libreria, xml);
        Files.write(destino, xml.toByteArray());
    }
}
