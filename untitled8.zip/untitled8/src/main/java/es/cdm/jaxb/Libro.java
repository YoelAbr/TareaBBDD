package es.cdm.jaxb;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LibroType", propOrder = {
        "titulo", "autor", "ejemplares", "editorial", "paginas", "anioEdicion"
})
public class Libro {
    @XmlAttribute(required = true)
    private String isbn;

    @XmlElement(required = true)
    private String titulo;
    @XmlElement(required = true)
    private String autor;
    @XmlElement(required = true)
    private int ejemplares;
    @XmlElement(required = true)
    private String editorial;
    @XmlElement(required = true)
    private int paginas;
    @XmlElement(required = true)
    private int anioEdicion;

    public Libro() {
        // JAXB necesita un constructor sin parámetros.
    }

    public String getIsbn() {
        return isbn;
    }

    public String getEditorial() {
        return editorial;
    }

    public int getEjemplares() {
        return ejemplares;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return "%s | %s | %s | %s | %d ejemplares | %d páginas | %d"
                .formatted(isbn, titulo, autor, editorial, ejemplares, paginas, anioEdicion);
    }
}
