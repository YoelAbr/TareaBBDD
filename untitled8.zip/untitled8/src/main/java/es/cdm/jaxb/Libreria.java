package es.cdm.jaxb;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "libreria")
@XmlAccessorType(XmlAccessType.FIELD)
public class Libreria {
    @XmlElement(name = "libro")
    private List<Libro> libros = new ArrayList<>();

    public Libreria() {
    }

    public List<Libro> getLibros() {
        return libros;
    }

    public Libro buscarPorIsbn(String isbn) {
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }

    public List<Libro> buscarPorEditorial(String editorial) {
        List<Libro> resultado = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getEditorial().equalsIgnoreCase(editorial)) {
                resultado.add(libro);
            }
        }
        return resultado;
    }

    public List<Libro> buscarConMinimoEjemplares(int minimo) {
        List<Libro> resultado = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getEjemplares() >= minimo) {
                resultado.add(libro);
            }
        }
        return resultado;
    }

    public Libro libroConMasEjemplares() {
        Libro maximo = null;
        for (Libro libro : libros) {
            if (maximo == null || libro.getEjemplares() > maximo.getEjemplares()) {
                maximo = libro;
            }
        }
        return maximo;
    }
}
