package es.cdm.jaxb;

import jakarta.xml.bind.JAXBException;

import org.xml.sax.SAXException;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Path XSD = Path.of("libreria.xsd");
    private static final Path SALIDA = Path.of("libreria-modificada.xml");

    public static void main(String[] args) {
        Path entrada = Path.of(args.length == 0 ? "libreria.xml" : args[0]);

        try (Scanner teclado = new Scanner(System.in)) {
            RepositorioXml repositorio = new RepositorioXml(XSD);
            Libreria libreria = repositorio.cargar(entrada);

            System.out.println("XML cargado: " + entrada);
            mostrarLibros(libreria.getLibros());

            while (true) {
                imprimirMenu();
                if (!teclado.hasNextLine()) {
                    return;
                }

                String opcion = teclado.nextLine().trim();
                switch (opcion) {
                    case "1" -> mostrarLibros(libreria.getLibros());
                    case "2" -> {
                        System.out.print("Editorial: ");
                        if (!teclado.hasNextLine()) return;
                        String editorial = teclado.nextLine().trim();
                        mostrarLibros(libreria.buscarPorEditorial(editorial));
                    }
                    case "3" -> buscarPorMinimo(libreria, teclado);
                    case "4" -> {
                        System.out.print("ISBN: ");
                        if (!teclado.hasNextLine()) return;
                        mostrarLibro(libreria.buscarPorIsbn(teclado.nextLine().trim()));
                    }
                    case "5" -> mostrarLibro(libreria.libroConMasEjemplares());
                    case "6" -> modificarTitulo(libreria, teclado);
                    case "7" -> {
                        try {
                            repositorio.guardar(libreria, SALIDA);
                            System.out.println("XML guardado y validado: " + SALIDA);
                        } catch (JAXBException | IOException e) {
                            System.err.println("No se pudo guardar: " + detalle(e));
                        }
                    }
                    case "0" -> {
                        System.out.println("Fin del programa.");
                        return;
                    }
                    default -> System.out.println("Opción no válida.");
                }
            }
        } catch (JAXBException | SAXException e) {
            System.err.println("No se pudo cargar el XML o el esquema: " + detalle(e));
        }
    }

    private static void imprimirMenu() {
        System.out.println("""

                1. Mostrar todos los libros
                2. Buscar por editorial
                3. Buscar por número mínimo de ejemplares
                4. Buscar por ISBN
                5. Mostrar el libro con más ejemplares
                6. Modificar título por ISBN
                7. Guardar XML
                0. Salir
                """);
        System.out.print("Opción: ");
    }

    private static void buscarPorMinimo(Libreria libreria, Scanner teclado) {
        System.out.print("Número mínimo de ejemplares: ");
        if (!teclado.hasNextLine()) return;

        try {
            int minimo = Integer.parseInt(teclado.nextLine().trim());
            if (minimo < 0) {
                System.out.println("El mínimo no puede ser negativo.");
                return;
            }
            mostrarLibros(libreria.buscarConMinimoEjemplares(minimo));
        } catch (NumberFormatException e) {
            System.out.println("Introduce un número entero válido.");
        }
    }

    private static void modificarTitulo(Libreria libreria, Scanner teclado) {
        System.out.print("ISBN del libro: ");
        if (!teclado.hasNextLine()) return;
        Libro libro = libreria.buscarPorIsbn(teclado.nextLine().trim());

        if (libro == null) {
            System.out.println("No se encontró ese ISBN.");
            return;
        }

        System.out.print("Nuevo título: ");
        if (!teclado.hasNextLine()) return;
        String titulo = teclado.nextLine().strip();

        if (titulo.isBlank()) {
            System.out.println("El título no puede estar vacío.");
            return;
        }

        libro.setTitulo(titulo);
        System.out.println("Título actualizado en memoria. Usa la opción 7 para guardar.");
    }

    private static void mostrarLibros(List<Libro> libros) {
        if (libros.isEmpty()) {
            System.out.println("No se encontraron libros.");
            return;
        }
        for (Libro libro : libros) {
            System.out.println(libro);
        }
    }

    private static void mostrarLibro(Libro libro) {
        System.out.println(libro == null ? "No se encontraron libros." : libro);
    }

    private static String detalle(Exception e) {
        if (e instanceof JAXBException jaxb && jaxb.getLinkedException() != null) {
            return jaxb.getLinkedException().getMessage();
        }
        return e.getMessage();
    }
}
